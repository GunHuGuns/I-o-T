# IoT 设备管理系统 - 离线版本

这是一个完整的 IoT 设备管理应用程序的离线 HTML 版本。

## 📦 项目内容

```
project-html/
├── index.html              # 主应用页面（离线版本）
├── static/                 # Next.js 生成的静态资源
│   ├── chunks/            # JavaScript 代码分割
│   ├── media/             # 媒体文件
│   └── gmRCqqZMCAKkrg_ydRtgr/  # Webpack 资源
├── public/                # 公共资源
│   ├── apple-icon.png
│   ├── icon-*.png
│   └── placeholder-*.png
└── README.md             # 本文件
```

## 🚀 使用方法

### 方案 1: 直接打开 HTML 文件（最简单）

1. 解压 `project-html.tar.gz` 文件
2. 用浏览器打开 `index.html` 即可使用

```bash
tar -xzf project-html.tar.gz
cd project-html
# 用浏览器打开 index.html
```

### 方案 2: 本地 Web 服务器（推荐）

由于浏览器安全限制，某些功能在本地 file:// 协议下可能受限。建议使用简单的 Web 服务器：

#### 使用 Python 3：
```bash
cd project-html
python -m http.server 8000
# 然后在浏览器中访问 http://localhost:8000
```

#### 使用 Python 2：
```bash
cd project-html
python -m SimpleHTTPServer 8000
```

#### 使用 Node.js (http-server)：
```bash
npm install -g http-server
cd project-html
http-server -p 8000
```

#### 使用 Live Server (VS Code 扩展)：
1. 在 VS Code 中安装 "Live Server" 扩展
2. 右键点击 index.html，选择 "Open with Live Server"

## ✨ 功能特性

### 🎧 耳机功能
- **均衡器控制**：标准、低音增强、人声增强、高音增强、自定义
- **10档音频调节**：精细控制每个频段
- **游戏模式**：低延迟音频处理
- **手势识别**：自定义左右耳双击/三击操作
- **高级设置**：空间音频、LHDC5.0、佩戴检测
- **翻译功能**：面对面翻译、通话翻译、同声传译
- **AI总结**：会议内容智能总结
- **定时停止**：指定时间点或倒计时停止播放

### ⌚ 手表功能
- **表盘市场**：100+ 精美表盘选择
- **应用管理**：应用下载和管理
- **运动模式**：100+ 运动类型支持
- **健康监测**：心率、睡眠、活动数据
- **支付功能**：NFC支付、交通卡、门禁卡

### 👤 个人中心
- 个人资料管理
- 健康档案编辑
- 健康目标设置
- 数据报告查看
- 通知设置
- 隐私和安全设置

## 🛠️ 技术栈

- **前端框架**：Next.js 16
- **UI 库**：React 19
- **样式**：Tailwind CSS 4
- **组件库**：Radix UI
- **图标**：Lucide React
- **类型检查**：TypeScript
- **表单管理**：React Hook Form
- **数据显示**：Recharts

## 📝 原始项目信息

这个项目是基于 Next.js 构建的完整 IoT 设备管理系统，包含以下页面：

### 核心页面
- `/` - 首页（已删除添加设备模块）
- `/devices` - 设备管理（已删除蓝牙图标）
- `/devices/[id]` - 设备详情（支持耳机和手表）
- `/profile` - 个人中心（已删除设置图标）

### 耳机专属路由
- `/devices/[id]/settings` - 高级设置（手势+音频）
- `/devices/[id]/translate/face-to-face` - 面对面翻译
- `/devices/[id]/translate/call` - 通话翻译
- `/devices/[id]/translate/simultaneous` - 同声传译
- `/devices/[id]/translate/summary` - AI 会议总结

### 手表专属路由
- `/devices/[id]/watch-faces` - 表盘市场
- `/devices/[id]/apps` - 应用管理
- `/devices/[id]/payment` - 钱包支付
- `/devices/[id]/cards` - 卡片管理

### 个人中心子页面
- `/profile/info` - 个人资料（头像上传）
- `/profile/health` - 健康档案（可编辑字段）
- `/profile/goals` - 健康目标
- `/profile/notifications` - 通知设置（时间选择器）
- `/profile/achievements` - 成就
- `/profile/reports` - 数据报告
- `/profile/help` - 帮助中心
- `/profile/privacy` - 隐私政策

## 🔧 离线版本的限制

由于这是静态 HTML 版本，以下功能受限：

1. **动态路由**：某些依赖 URL 参数的页面无法直接访问
   - 解决方案：在构建时需要预渲染特定的路由参数

2. **数据持久化**：无后端支持，数据仅存储在浏览器本地
   - 使用 LocalStorage 或 IndexedDB 实现

3. **API 调用**：网络请求功能需要 mock 实现
   - 应用使用模拟数据演示功能

4. **实时同步**：无法与云端服务器同步

## 📦 构建原始项目

如果需要重新构建该项目（需要 Node.js）：

```bash
# 安装依赖
pnpm install

# 开发模式
pnpm dev

# 生产构建
pnpm build

# 启动生产服务器
pnpm start
```

## 🌐 在线版本

原始项目已部署在 Vercel 上：
- GitHub 仓库：`GunHuGuns/I-o-T`
- 分支：`v0/choosinggeter-8737-a10a253a`

## 📄 许可证

该项目为示例应用程序。

## 💡 常见问题

### Q: 可以在没有 Web 服务器的情况下使用吗？
A: 可以，但某些浏览器功能（如某些 API）需要 HTTPS 或 localhost。推荐使用本地 Web 服务器。

### Q: 如何修改应用内容？
A: 
1. 编辑 `index.html` 中的 HTML/CSS
2. 修改 JavaScript 代码
3. 刷新浏览器即可看到更改

### Q: 图片和资源在哪里？
A: 
- 公共资源存储在 `public/` 目录中
- 构建产物存储在 `static/` 目录中

### Q: 如何导出为其他格式？
A: 可以使用浏览器的打印功能（Ctrl+P）保存为 PDF

---

**最后更新**：2024-05-19
**版本**：1.0.0
