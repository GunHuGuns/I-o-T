@echo off
chcp 65001 >nul
echo ================================
echo IoT 设备管理系统 - 快速启动
echo ================================
echo.

where python3 >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo ✓ 检测到 Python 3
    echo.
    echo 正在启动本地服务器...
    echo 访问地址: http://localhost:8000
    echo 按 Ctrl+C 停止服务器
    echo.
    python3 -m http.server 8000
    exit /b
)

where python >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo ✓ 检测到 Python
    echo.
    echo 正在启动本地服务器...
    echo 访问地址: http://localhost:8000
    echo 按 Ctrl+C 停止服务器
    echo.
    python -m http.server 8000
    exit /b
)

where node >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo ✓ 检测到 Node.js
    echo.
    where http-server >nul 2>&1
    if %ERRORLEVEL% NEQ 0 (
        echo 安装 http-server...
        npm install -g http-server
    )
    echo 正在启动本地服务器...
    echo 访问地址: http://localhost:8000
    echo 按 Ctrl+C 停止服务器
    echo.
    http-server -p 8000
    exit /b
)

echo ✗ 未检测到任何 Python 或 Node.js
echo.
echo 请安装以下之一：
echo 1. Python (https://www.python.org)
echo 2. Node.js (https://nodejs.org)
echo.
echo 或者直接用浏览器打开 index.html
pause
